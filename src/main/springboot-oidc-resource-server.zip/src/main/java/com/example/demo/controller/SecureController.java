package com.example.demo.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SecureController {

  @GetMapping("/api/secure-data")
  public Map<String, Object> secureData(@AuthenticationPrincipal Jwt jwt) {
    return Map.of(
      "message", "This is protected data from resource server.",
      "subject", jwt.getSubject(),
      "email", jwt.getClaimAsString("email"),
      "roles", jwt.getClaimAsStringList("roles")
    );
  }
}
